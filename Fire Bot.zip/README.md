
# My discord bot 

See my bot files




## Security Folder

I have a folder with .json files in which store the ID of the client, development server, database key and token, if you want to use my code, you must add this folder
## Tech Stack

**Client:** Discord.js v14

**Server:** Nodemon 

